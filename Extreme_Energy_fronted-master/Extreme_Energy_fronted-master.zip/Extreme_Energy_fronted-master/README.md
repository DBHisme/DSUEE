# frontend

#### 安装教程
首次启动前
npm install

#### 使用说明
启动
npm run serve
如果启动失败执行
$env:NODE_OPTIONS="--openssl-legacy-provider"
再执行
npm run serve
