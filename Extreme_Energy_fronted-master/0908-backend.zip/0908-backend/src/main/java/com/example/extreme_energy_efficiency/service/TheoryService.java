package com.example.extreme_energy_efficiency.service;

import com.example.extreme_energy_efficiency.beans.TheoryData;

public interface TheoryService {

}
