package com.example.extreme_energy_efficiency.service;

public interface ConvertRatioService {
}
