package com.example.extreme_energy_efficiency.dao;

import com.example.extreme_energy_efficiency.dao.entity.ActualEntity;

public interface ActualEntityMapper {
    ActualEntity getFormulas(String ID);
}
